﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Chain;
using ChainLib;
using System.Drawing;
using System.Collections.Generic;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestButton1()
        {
            Form1 f = new Form1();
            int nachx = 0;
            int x = 100;
            int xrez = 200;

            Assert.AreEqual(nachx, f.X, "Ошибка!");

            f.button2_Click(null, null);
            Assert.AreEqual(x, f.X, "Ошибка!");

            f.button1_Click(null, null);
            Assert.AreEqual(xrez, f.X, "Ошибка!");

            f.button5_Click(null, null);
            Assert.AreEqual(300, f.X, "Ошибка!");
        }
    }

    [TestClass]
    public class UnitTest2
    {
        Bitmap picL = new Bitmap(@"C:\Users\Саша\Desktop\Визуалка\лаби арітектура\Келементи\loco.png");
        TrainSob t;

        [TestMethod]
        public void TestMove()
        {
            int x = 10;
            int rezx = 5;
            t = new TrainSob(1,x, picL);
            t.move();
            Assert.AreEqual(rezx, t.x, "Ошибка!");
        }

        [TestMethod]
        public void TestPic()
        {
            t = new TrainSob(1, 1, picL);
            Assert.AreEqual(t.pic, picL, "Ошибка!");
        }
    }

    [TestClass]
    public class UnitTest3
    {
        TrainSob t;

        [TestMethod]
        public void TestClass()
        {
            int x = 10;
            Bitmap picL = new Bitmap(@"C:\Users\Саша\Desktop\Визуалка\лаби арітектура\Келементи\loco.png");
            int s = 1;

            t = new TrainSob(s, x, picL);

            Assert.AreEqual(x, t.x, "Ошибка!");
            Assert.AreEqual(picL, t.pic,  "Ошибка!");
            Assert.AreEqual(s, t.size,"Ошибка!");
        }
    }

    [TestClass]
    public class UnitTest4
    {
        TrainSob t;
        Bitmap picL = new Bitmap(@"C:\Users\Саша\Desktop\Визуалка\лаби арітектура\Келементи\loco.png");

        [TestMethod]
        public void TestVagon1()
        {
            t = new TrainSob(1, 1, picL);

            List<TrainSob> ts = new List<TrainSob>();
            ts.Add(t);

            loco v = new vagon1();
            v.Req(t);

            Assert.AreEqual(ts.Count, v.tts.Count, "Ошибка!");
        }

        [TestMethod]
        public void TestVagon2()
        {
            t = new TrainSob(2, 1, picL);

            List<TrainSob> ts = new List<TrainSob>();
            ts.Add(t);

            loco v = new vagon2();
            v.Req(t);

            Assert.AreEqual(ts.Count, v.tts.Count, "Ошибка!");
        }
    }

    [TestClass]
    public class UnitTest5
    {
        [TestMethod]
        public void TestNextTo()
        {
            Train t = new loco();
            loco l = new vagon1();

            l.NextTo(t);

            Assert.AreEqual(t, l.next, "Ошибка!");

        }
    }
}
